<?php 
namespace Hiden;


use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerToggleSneakEvent;
use pocketmine\utils\TextFormat;
use pocketmine\entity\Effect;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;


class Hiden extends PluginBase implements Listener{
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$pdFile=$this->getDescription();
		$this->getLogger()->info(TextFormat::DARK_BLUE."[고개숙이고 두리번] 플러그인이 활성화 되었습니다.");
	}
	
	public function onDisable(){
		$pdFile=$this->getDescription();
		$this->getLogger()->info(TextFormat::RED."[고개숙이고 두리번]플러그인이 비활성화 되었습니다.");
	}
	
	public function onHide(PlayerToggleSneakEvent $event){
		$player=$event->getPlayer();
		if($event->isSneaking()){
			   $effect= Effect::getEffect(14);
			   $effect->setDuration (600 * 20);
			   $effect->setAmplifier (10);
			   $player->addEffect($effect);
			} 
			elseif(!$event->isSneaking()){
		
				$player->removeEffect(14);
				
			}
	}
	
	public function onCommand(CommandSender $Player,Command $command, $label,array $args){
		if(strtolower($command->getName())=="HideOn"){
			
		}
		if(strotolower($command->getName())=="HideOff"){
			
	}
}
}
			

?>